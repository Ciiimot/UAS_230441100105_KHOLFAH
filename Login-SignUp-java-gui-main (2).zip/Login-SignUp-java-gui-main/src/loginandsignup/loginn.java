
package loginandsignup;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class loginn extends javax.swing.JFrame {
  Connection conn;
   
    public loginn() {
        initComponents();
        conn = koneksi.getConnection(); // Pastikan metode koneksi ini benar-benar terhubung ke database;
    }
     // Fungsi untuk memverifikasi login
    private void Login() {
        String username = tfpw.getText();
        String password = new String(textfieldpw.getPassword());
        
        // Menggunakan koneksi database untuk memeriksa login
        try (Connection conn = koneksi.getConnection()) {
            String query = "SELECT role,user_id FROM users WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String role = rs.getString("role");
                 int id = rs.getInt("user_id");
                if ("admin".equals(role)) {
                    JOptionPane.showMessageDialog(this, "Login berhasil sebagai Admin!");
                   new adminn().setVisible(true);
                } else if ("customer".equals(role)) {
                    JOptionPane.showMessageDialog(this, "Login berhasil sebagai Customer!");
                    new cust(id).setVisible(true);
                }
                this.dispose(); // Tutup frame login
            } else {
                JOptionPane.showMessageDialog(this, "Username atau Password salah!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Koneksi gagal: " + e.getMessage());
        }
    }

    // Fungsi untuk membuka form buat akun
    private void buatakun() {
        // Membuka frame buat akun
        new signup1().setVisible(true);
        this.dispose(); // Menutup login frame
    }


    


        @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Right = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        Left = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        namelabel = new javax.swing.JLabel();
        labelpw = new javax.swing.JLabel();
        textfieldpw = new javax.swing.JPasswordField();
        buttonlogin = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        buttonsignup = new javax.swing.JButton();
        tfpw = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));
        jPanel1.setLayout(null);

        Right.setBackground(new java.awt.Color(0, 0, 0));
        Right.setPreferredSize(new java.awt.Dimension(400, 500));
        Right.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        Right.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(145, 136, -1, -1));

        jLabel6.setFont(new java.awt.Font("Showcard Gothic", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Company Name");
        Right.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, -1, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 204, 204));
        jLabel7.setText("copyright © company name All rights reserved");
        Right.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(81, 402, -1, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\USER EBC\\Downloads\\lpt-removebg-preview (1).png")); // NOI18N
        Right.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, -1, -1));

        jPanel1.add(Right);
        Right.setBounds(0, 0, 400, 500);

        Left.setBackground(new java.awt.Color(207, 117, 0));
        Left.setMinimumSize(new java.awt.Dimension(400, 500));
        Left.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setText("LOGIN");
        Left.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(138, 51, -1, -1));

        namelabel.setBackground(new java.awt.Color(102, 102, 102));
        namelabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        namelabel.setText("Username");
        Left.add(namelabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 139, -1, -1));

        labelpw.setBackground(new java.awt.Color(102, 102, 102));
        labelpw.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        labelpw.setText("Password");
        Left.add(labelpw, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 229, -1, -1));

        textfieldpw.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textfieldpwActionPerformed(evt);
            }
        });
        Left.add(textfieldpw, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 343, 40));

        buttonlogin.setBackground(new java.awt.Color(227, 176, 75));
        buttonlogin.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        buttonlogin.setForeground(new java.awt.Color(255, 255, 255));
        buttonlogin.setText("Login");
        buttonlogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonloginActionPerformed(evt);
            }
        });
        Left.add(buttonlogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 327, 93, 36));

        jLabel4.setText("I don't have an account");
        Left.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 402, -1, -1));

        buttonsignup.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        buttonsignup.setForeground(new java.awt.Color(255, 51, 51));
        buttonsignup.setText("Sign Up");
        buttonsignup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonsignupActionPerformed(evt);
            }
        });
        Left.add(buttonsignup, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 396, -1, -1));

        tfpw.setText("jTextField1");
        Left.add(tfpw, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, 340, 50));

        jPanel1.add(Left);
        Left.setBounds(400, 0, 400, 500);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonloginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonloginActionPerformed
         Login();
    }//GEN-LAST:event_buttonloginActionPerformed

    private void buttonsignupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonsignupActionPerformed
    buatakun();
    }//GEN-LAST:event_buttonsignupActionPerformed

    private void textfieldpwActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textfieldpwActionPerformed
//        if (isPasswordVisible) {
//        textfieldpw.setEchoChar('*'); // Sembunyikan password
//        isPasswordVisible = false; // Ubah status menjadi tidak terlihat
//    } else {
//        textfieldpw.setEchoChar((char) 0); // Tampilkan password
//        isPasswordVisible = true; // Ubah status menjadi terlihat
//    }
    }//GEN-LAST:event_textfieldpwActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(loginn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(loginn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(loginn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(loginn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new loginn().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Left;
    private javax.swing.JPanel Right;
    private javax.swing.JButton buttonlogin;
    private javax.swing.JButton buttonsignup;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labelpw;
    private javax.swing.JLabel namelabel;
    private javax.swing.JPasswordField textfieldpw;
    private javax.swing.JTextField tfpw;
    // End of variables declaration//GEN-END:variables
}
