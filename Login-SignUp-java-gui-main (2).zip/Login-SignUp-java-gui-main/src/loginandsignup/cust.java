
package loginandsignup;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class cust extends javax.swing.JFrame {
    private Connection conn= koneksi.getConnection();
    int iid;

    public cust(int id) { 
        initComponents();
        this.iid = id;
        loadCustomerTableData();
        loadBookingTableData();
    }
 // ---------------- Tab Manage Data ---------------- //
    private void loadCustomerTableData() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);

        try (PreparedStatement stmt = conn.prepareStatement("SELECT * FROM customerprofile")) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("profile_id"),
                    rs.getString("name"),
                    rs.getString("address"),
                    rs.getString("phone_number"),
                    rs.getString("Nik")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error loading customer data: " + e.getMessage());
        }
    }

   private void loadBookingTableData() {
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.setRowCount(0);

        try (PreparedStatement stmt = conn.prepareStatement("SELECT * FROM bookings")) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("booking_id"),
                    rs.getInt("user_id"),
                    rs.getString("room_type"),
                    rs.getDate("check_in_date"),
                    rs.getDate("check_out_date"),
                    rs.getDouble("total_price"),
                    rs.getInt("total_rooms"),
                    rs.getInt("stay_duration")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error loading booking data: " + e.getMessage());
        }
}
    private void calculateStayDuration() {
        try {
            Date checkIn = jDateChooser1.getDate();
            Date checkOut = jDateChooser2.getDate();

            long diff = checkOut.getTime() - checkIn.getTime();
            long days = diff / (1000 * 60 * 60 * 24);

            lama.setText(String.valueOf(days));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error calculating stay duration: " + e.getMessage());
        }
    }
    private void calculateTotalPrice() {
        try {
            int stayDuration = Integer.parseInt(lama.getText());
            int totalRooms = Integer.parseInt(jttk.getText());
            int roomRate = Integer.parseInt(combotipe.getSelectedItem().toString()); // Example: Using combobox value as price

            int totalPrice = stayDuration * totalRooms * roomRate;
            jtharga.setText(String.valueOf(totalPrice));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error calculating total price: " + e.getMessage());
        }
    }


 
    
                
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jlnmcust1 = new javax.swing.JLabel();
        jtfcust1 = new javax.swing.JTextField();
        jlhpc1 = new javax.swing.JLabel();
        tfhpc1 = new javax.swing.JTextField();
        jljenis1 = new javax.swing.JLabel();
        combojk = new javax.swing.JComboBox<>();
        jlalamat1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jlnik = new javax.swing.JLabel();
        jtnik = new javax.swing.JTextField();
        jbtambah1 = new javax.swing.JButton();
        jbedit1 = new javax.swing.JButton();
        jbhapus1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        nokar2 = new javax.swing.JLabel();
        cbn2 = new javax.swing.JComboBox<>();
        idpel2 = new javax.swing.JLabel();
        cbid2 = new javax.swing.JComboBox<>();
        jlin = new javax.swing.JLabel();
        jlout = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jltipe = new javax.swing.JLabel();
        combotipe = new javax.swing.JComboBox<>();
        jltotal = new javax.swing.JLabel();
        jtharga = new javax.swing.JTextField();
        jllm = new javax.swing.JLabel();
        lama = new javax.swing.JTextField();
        jlhari = new javax.swing.JLabel();
        tk = new javax.swing.JLabel();
        jttk = new javax.swing.JTextField();
        jluang = new javax.swing.JLabel();
        tfuang = new javax.swing.JTextField();
        jlsusuk = new javax.swing.JLabel();
        tfsusuk = new javax.swing.JTextField();
        jbbook = new javax.swing.JButton();
        jbcancel = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();

        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\USER EBC\\Downloads\\gd-removebg-preview.png")); // NOI18N
        jLabel6.setText("jLabel6");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(15, 15, 15));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USER EBC\\Downloads\\logo1.png")); // NOI18N
        jPanel1.add(jLabel1);

        jTabbedPane1.setBackground(new java.awt.Color(207, 117, 0));

        jPanel2.setBackground(new java.awt.Color(15, 15, 15));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jlnmcust1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlnmcust1.setForeground(new java.awt.Color(255, 255, 255));
        jlnmcust1.setText("Nama Pelanggan");
        jPanel2.add(jlnmcust1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));
        jPanel2.add(jtfcust1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 150, -1));

        jlhpc1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlhpc1.setForeground(new java.awt.Color(255, 255, 255));
        jlhpc1.setText("No Hp");
        jPanel2.add(jlhpc1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 90, -1));
        jPanel2.add(tfhpc1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 150, -1));

        jljenis1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jljenis1.setForeground(new java.awt.Color(255, 255, 255));
        jljenis1.setText("Jenis Kelamin");
        jPanel2.add(jljenis1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 150, -1));

        combojk.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        combojk.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pria", "Wanita" }));
        jPanel2.add(combojk, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 150, -1));

        jlalamat1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlalamat1.setForeground(new java.awt.Color(255, 255, 255));
        jlalamat1.setText("Alamat");
        jPanel2.add(jlalamat1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 80, 20));

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, 200, -1));

        jlnik.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlnik.setForeground(new java.awt.Color(255, 255, 255));
        jlnik.setText("Nik");
        jPanel2.add(jlnik, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 40, -1));
        jPanel2.add(jtnik, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 150, -1));

        jbtambah1.setBackground(new java.awt.Color(207, 117, 0));
        jbtambah1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jbtambah1.setForeground(new java.awt.Color(255, 255, 255));
        jbtambah1.setText("Tambah");
        jbtambah1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtambah1ActionPerformed(evt);
            }
        });
        jPanel2.add(jbtambah1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 410, -1, -1));

        jbedit1.setBackground(new java.awt.Color(207, 117, 0));
        jbedit1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jbedit1.setForeground(new java.awt.Color(255, 255, 255));
        jbedit1.setText("Edit");
        jbedit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbedit1ActionPerformed(evt);
            }
        });
        jPanel2.add(jbedit1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 410, -1, -1));

        jbhapus1.setBackground(new java.awt.Color(15, 15, 15));
        jbhapus1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jbhapus1.setForeground(new java.awt.Color(255, 255, 255));
        jbhapus1.setText("Hapus");
        jbhapus1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbhapus1ActionPerformed(evt);
            }
        });
        jPanel2.add(jbhapus1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, -1, -1));

        jTable1.setAutoCreateRowSorter(true);
        jTable1.setBackground(new java.awt.Color(250, 235, 205));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nama", "No Hp", "Jenis Kelamin", "Alamat", "Nik"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 60, 490, 360));

        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\USER EBC\\Downloads\\malam (1) (2).jpg")); // NOI18N
        jLabel3.setText("jLabel3");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1, -10, 1250, -1));

        jTabbedPane1.addTab("MANAGE DATA", jPanel2);

        jPanel3.setBackground(new java.awt.Color(15, 15, 15));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nokar2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        nokar2.setForeground(new java.awt.Color(255, 255, 255));
        nokar2.setText("Nomor Kamar");
        jPanel3.add(nokar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jPanel3.add(cbn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 96, -1));

        idpel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        idpel2.setForeground(new java.awt.Color(255, 255, 255));
        idpel2.setText("ID Pelanggan");
        jPanel3.add(idpel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, -1, -1));

        cbid2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        jPanel3.add(cbid2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 100, -1));

        jlin.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlin.setForeground(new java.awt.Color(255, 255, 255));
        jlin.setText("Tanggal Chek In");
        jPanel3.add(jlin, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, -1, -1));

        jlout.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlout.setForeground(new java.awt.Color(255, 255, 255));
        jlout.setText("Tanggal Chek Out");
        jPanel3.add(jlout, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\USER EBC\\Downloads\\gedung-removebg-preview.png")); // NOI18N
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 660, -1, -1));

        jltipe.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jltipe.setForeground(new java.awt.Color(255, 255, 255));
        jltipe.setText("Tipe Kamar");
        jPanel3.add(jltipe, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 70, -1, -1));

        combotipe.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Standard", "Deluxe", "Suite", "" }));
        combotipe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combotipeActionPerformed(evt);
            }
        });
        jPanel3.add(combotipe, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 100, 110, -1));

        jltotal.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jltotal.setForeground(new java.awt.Color(255, 255, 255));
        jltotal.setText("Total");
        jPanel3.add(jltotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 140, 80, -1));
        jPanel3.add(jtharga, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 170, 110, -1));

        jllm.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jllm.setForeground(new java.awt.Color(255, 255, 255));
        jllm.setText("Lama Menginap");
        jPanel3.add(jllm, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 120, -1));
        jPanel3.add(lama, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 50, -1));

        jlhari.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlhari.setForeground(new java.awt.Color(255, 255, 255));
        jlhari.setText("Hari");
        jPanel3.add(jlhari, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 280, -1, -1));

        tk.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tk.setForeground(new java.awt.Color(255, 255, 255));
        tk.setText("Total Kamar");
        jPanel3.add(tk, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 10, -1, -1));
        jPanel3.add(jttk, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 40, 100, -1));

        jluang.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jluang.setForeground(new java.awt.Color(255, 255, 255));
        jluang.setText("Uang yang di bayar");
        jPanel3.add(jluang, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 210, -1, -1));
        jPanel3.add(tfuang, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 240, 110, -1));

        jlsusuk.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlsusuk.setForeground(new java.awt.Color(255, 255, 255));
        jlsusuk.setText("Kembalian");
        jPanel3.add(jlsusuk, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 280, 90, -1));

        tfsusuk.setForeground(new java.awt.Color(255, 255, 255));
        tfsusuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfsusukActionPerformed(evt);
            }
        });
        jPanel3.add(tfsusuk, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 310, 110, -1));

        jbbook.setText("BOOK");
        jbbook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbbookActionPerformed(evt);
            }
        });
        jPanel3.add(jbbook, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 310, -1, -1));

        jbcancel.setText("CANCEL");
        jbcancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbcancelActionPerformed(evt);
            }
        });
        jPanel3.add(jbcancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 310, -1, -1));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nomor Kamar", "ID Pelanggan", "Tanggal Chek In", "Tanggal Chek Out", "Lama Menginap", "Total Kamar", "Tipe Kamar", "Harga", "Uang yang dibayar", "Kembalian"
            }
        ));
        jScrollPane3.setViewportView(jTable2);

        jPanel3.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, 1100, 200));

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\USER EBC\\Downloads\\ha-removebg-preview.png")); // NOI18N
        jLabel7.setText("jLabel7");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 340, -1, 280));

        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\USER EBC\\Downloads\\gedung-removebg-preview.png")); // NOI18N
        jLabel8.setText("jLabel8");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, -1, -1));

        jDateChooser1.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jDateChooser1AncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jPanel3.add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 100, -1));

        jDateChooser2.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jDateChooser2AncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jPanel3.add(jDateChooser2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 100, -1));

        jTabbedPane1.addTab("MANAGE BOOKING", jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 659, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbedit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbedit1ActionPerformed
      // Action Event untuk Tombol Edit                                   
    // Validasi Input
    if ( combojk.getSelectedItem().toString().isEmpty()|| jtfcust1.getText().isEmpty() || jTextArea1.getText().isEmpty() 
        || tfhpc1.getText().isEmpty() || jtnik.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Harap isi semua kolom terlebih dahulu!", "Input Error", JOptionPane.WARNING_MESSAGE);
        return;
    }

    try {
        // Ambil Data dari Input
        int profileId = Integer.parseInt((String) combojk.getSelectedItem());
        String name = jtfcust1.getText();
        String address = jTextArea1.getText();
        String phoneNumber = tfhpc1.getText();
        String nik = jtnik.getText();

        // Update Data Pelanggan
        String sql = "UPDATE customerprofile SET name = ?, address = ?, phone_number = ?, Nik = ? WHERE profile_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setString(2, address);
            stmt.setString(3, phoneNumber);
            stmt.setString(4, nik);
            stmt.setInt(5, profileId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(this, "Data pelanggan berhasil diperbarui!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                loadCustomerTableData(); // Refresh Tabel
            } else {
                JOptionPane.showMessageDialog(this, "ID pelanggan tidak ditemukan.", "Gagal", JOptionPane.ERROR_MESSAGE);
            }
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Profile ID harus berupa angka!", "Input Error", JOptionPane.WARNING_MESSAGE);
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error saat memperbarui data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace(); // Debug ke konsol
    }

    }//GEN-LAST:event_jbedit1ActionPerformed

    private void jbhapus1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbhapus1ActionPerformed
       int profileId = Integer.parseInt((String) combojk.getSelectedItem());

        try (PreparedStatement stmt = conn.prepareStatement("DELETE FROM customerprofile WHERE profile_id = ?")) {
            stmt.setInt(1, profileId);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Customer deleted successfully!");
            loadCustomerTableData();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error deleting customer: " + e.getMessage());
        }

    }//GEN-LAST:event_jbhapus1ActionPerformed

    private void jbcancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbcancelActionPerformed
   
    }//GEN-LAST:event_jbcancelActionPerformed

    private void tfsusukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfsusukActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfsusukActionPerformed

    private void combotipeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combotipeActionPerformed
         
    }//GEN-LAST:event_combotipeActionPerformed

    private void jbbookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbbookActionPerformed
      try {
            int userId = Integer.parseInt(cbid2.getSelectedItem().toString());
            String roomType = combotipe.getSelectedItem().toString();
            Date checkIn = jDateChooser1.getDate();
            Date checkOut = jDateChooser2.getDate();
            int stayDuration = Integer.parseInt(lama.getText());
            int totalRooms = Integer.parseInt(jttk.getText());
            double totalPrice = Double.parseDouble(jtharga.getText());

            try (PreparedStatement stmt = conn.prepareStatement("INSERT INTO bookings (user_id, room_type, check_in_date, check_out_date, stay_duration, total_rooms, total_price) VALUES (?, ?, ?, ?, ?, ?, ?)")) {
                stmt.setInt(1, userId);
                stmt.setString(2, roomType);
                stmt.setDate(3, new java.sql.Date(checkIn.getTime()));
                stmt.setDate(4, new java.sql.Date(checkOut.getTime()));
                stmt.setInt(5, stayDuration);
                stmt.setInt(6, totalRooms);
                stmt.setDouble(7, totalPrice);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "Booking added successfully!");
                loadBookingTableData();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error adding booking: " + e.getMessage());
        }
    
    }//GEN-LAST:event_jbbookActionPerformed

    private void jDateChooser1AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jDateChooser1AncestorAdded
          
    }//GEN-LAST:event_jDateChooser1AncestorAdded

    private void jDateChooser2AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jDateChooser2AncestorAdded
        
    }//GEN-LAST:event_jDateChooser2AncestorAdded

    private void jbtambah1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtambah1ActionPerformed
        // TODO add your handling code here:
        String name = jtfcust1.getText();
        String address = jTextArea1.getText();
        String phoneNumber = tfhpc1.getText();
        String nik = jtnik.getText();

        try {
            String sql = "INSERT INTO customerprofile (user_id,name, address, phone_number, Nik) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, iid);
            stmt.setString(2, name);
            stmt.setString(3, address);
            stmt.setString(4, phoneNumber);
            stmt.setString(5, nik);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Customer added successfully!");
            loadCustomerTableData();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error adding customer: " + e.getMessage());
        }
    }//GEN-LAST:event_jbtambah1ActionPerformed
  
    
    public static void main(String args[]) {
   
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new cust(0).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbid2;
    private javax.swing.JComboBox<String> cbn2;
    private javax.swing.JComboBox<String> combojk;
    private javax.swing.JComboBox<String> combotipe;
    private javax.swing.JLabel idpel2;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JButton jbbook;
    private javax.swing.JButton jbcancel;
    private javax.swing.JButton jbedit1;
    private javax.swing.JButton jbhapus1;
    private javax.swing.JButton jbtambah1;
    private javax.swing.JLabel jlalamat1;
    private javax.swing.JLabel jlhari;
    private javax.swing.JLabel jlhpc1;
    private javax.swing.JLabel jlin;
    private javax.swing.JLabel jljenis1;
    private javax.swing.JLabel jllm;
    private javax.swing.JLabel jlnik;
    private javax.swing.JLabel jlnmcust1;
    private javax.swing.JLabel jlout;
    private javax.swing.JLabel jlsusuk;
    private javax.swing.JLabel jltipe;
    private javax.swing.JLabel jltotal;
    private javax.swing.JLabel jluang;
    private javax.swing.JTextField jtfcust1;
    private javax.swing.JTextField jtharga;
    private javax.swing.JTextField jtnik;
    private javax.swing.JTextField jttk;
    private javax.swing.JTextField lama;
    private javax.swing.JLabel nokar2;
    private javax.swing.JTextField tfhpc1;
    private javax.swing.JTextField tfsusuk;
    private javax.swing.JTextField tfuang;
    private javax.swing.JLabel tk;
    // End of variables declaration//GEN-END:variables
}
