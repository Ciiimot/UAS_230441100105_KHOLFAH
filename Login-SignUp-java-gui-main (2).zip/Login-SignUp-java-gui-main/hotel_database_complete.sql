-- Menambahkan kolom amount_paid dan change ke tabel Bookings untuk mendukung fitur informasi pembayaran di UI
ALTER TABLE Bookings
ADD COLUMN amount_paid DECIMAL(10, 2) DEFAULT 0,
ADD COLUMN change DECIMAL(10, 2) GENERATED ALWAYS AS (amount_paid - total_price) STORED;
